
    
    
from autobahn.twisted.component import Component, run 
from twisted.internet.defer import inlineCallbacks 
from autobahn.twisted.util import sleep 



@inlineCallbacks
def intro(session):
    yield session.call("rie.dialogue.say", text="Ik kan 3 taken uitvoeren. Dit zijn:")
     
    yield session.call("rie.dialogue.say", text="Het geven van een locatie van een kamer")
    
    yield session.call("rie.dialogue.say", text="het geven van een locatie van een persoon")
    
    yield session.call("rie.dialogue.say", text="en tot slot. praktische informatie over het snellius.")  

@inlineCallbacks
def select(session):
    yield session.call("rie.dialogue.say", text="Voor locatie van een kamer kies 1")
    yield session.call("rie.dialogue.say", text="Voor locatie van een persoon kies 2")
    yield session.call("rie.dialogue.say", text="Voor praktische informatie kies 3")

@inlineCallbacks 
def main(session, details): 
    
    yield session.call(u'rie.dialogue.config.language',lang=u'nl')
    wave = session.call("rom.optional.behavior.play", name="BlocklyWaveRightArm")
    yield session.call("rie.dialogue.say", text="Hallo ik ben Pepper. Ik ben de receptionist van het Snellius")
    yield wave
    
    yield intro(session)
    yield select(session)
    session.leave() 

# Create wamp connection 
wamp = Component( transports=[{ "url": "ws://wamp.robotsindeklas.nl",
                               "serializers": ["msgpack"],
                               "max_retries": 0 }], realm=u"rie.63492440b8702f62b71165b2", ) # realm of nao v6-2rie.634922ecb8702f62b7116597
                                                                                              #realm of alpha mini rie.63492440b8702f62b71165b2
wamp.on_join(main)
if __name__ == "__main__":
    run([wamp])